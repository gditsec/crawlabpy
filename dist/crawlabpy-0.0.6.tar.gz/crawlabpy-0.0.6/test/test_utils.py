from crawlabpy.utils import PART_CONTENT_TYPE, notify_target

print(PART_CONTENT_TYPE)
# notify_target()
